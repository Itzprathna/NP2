-- =========================================================
-- NEXTPath migration v5: distinct set for EVERY education level
-- High School, Higher Secondary, Undergraduate, Graduate and
-- Postgraduate each get their own pool: 10 level-specific
-- questions + shared general questions to fill the length.
-- Scoring is unchanged (question_option_weights).
-- =========================================================

USE nextpath;

-- Widen the enum first (existing 'school'/'college' values stay valid).
ALTER TABLE questions MODIFY level_group ENUM('all','school','college','high_school','higher_secondary','undergraduate','graduate','postgraduate') NOT NULL DEFAULT 'all';

-- Split the old 'school' pool (ids 9, 36-43).
UPDATE questions SET level_group = 'high_school'
  WHERE id IN (36, 37, 40, 43);
UPDATE questions SET level_group = 'higher_secondary'
  WHERE id IN (9, 38, 39, 41, 42);

-- Split the old 'college' pool (ids 12, 28, 44-51).
UPDATE questions SET level_group = 'undergraduate'
  WHERE id IN (44, 45, 46);
UPDATE questions SET level_group = 'graduate'
  WHERE id IN (12, 47, 48, 50);
UPDATE questions SET level_group = 'postgraduate'
  WHERE id IN (28, 49, 51);

-- Narrow the enum to the final set (no rows use school/college now).
ALTER TABLE questions MODIFY level_group ENUM('all','high_school','higher_secondary','undergraduate','graduate','postgraduate') NOT NULL DEFAULT 'all';

-- 6 High School questions (ids 52-57; pool already has 36, 37, 40, 43).
INSERT INTO questions (id, category_id, level_group, question_text, option_a, option_b, option_c, option_d, option_e, correct_answer) VALUES
(52, 8, 'high_school', 'On a Sunday at home, what do you end up doing first?', 'Fixing your bicycle or a home appliance', 'Watering plants and noting which grow fastest', 'Filling a sketchbook with cartoons', 'Rearranging your room to look better', 'Reading storybooks for hours', NULL),
(53, 13, 'high_school', 'Which school competition would you join tomorrow?', 'A handwriting contest', 'Solo singing or dance', 'The 100-metre race', 'A chess tournament', 'Clay modelling', NULL),
(54, 2, 'high_school', 'What do you do with an old notebook full of blank pages?', 'Make a budget diary for small expenses', 'Start a comic story in it', 'Note cricket scores and player stats', 'Gift it to a junior who needs it', 'Press leaves and flowers and label them', NULL),
(55, 26, 'high_school', 'What duty would you love in the morning assembly?', 'Leading the prayer or the pledge', 'Playing in the school band', 'Managing the mic and speakers', 'Marching in the parade', 'Reading out the daily news', NULL),
(56, 3, 'high_school', 'A relative gifts you Rs. 1000. What do you do?', 'Put it straight in your piggy bank', 'Buy a science experiment kit', 'Buy colours and craft material', 'Treat your friends to snacks', 'Donate part to a classmate in need', NULL),
(57, 24, 'high_school', 'Which library bookshelf pulls you first?', 'Space and dinosaurs', 'Jokes and comics', 'Sports magazines', 'Stories of great inventors', 'Puzzle and riddle books', NULL);

-- 5 Higher Secondary questions (ids 58-62; pool already has 9, 38, 39, 41, 42).
INSERT INTO questions (id, category_id, level_group, question_text, option_a, option_b, option_c, option_d, option_e, correct_answer) VALUES
(58, 8, 'higher_secondary', 'It is stream-selection week. What excites you most?', 'Physics problems and derivations', 'Tallying the canteen''s daily collection', 'Designing the farewell banner', 'The youth-parliament debate', 'Counselling juniors about their streams', NULL),
(59, 7, 'higher_secondary', 'One free hour after coaching classes. What do you do?', 'Extra mock-test practice', 'Editing a reel from today''s fun moments', 'The gym or a quick run', 'A paid poster for a nearby shop', 'Calling home and helping with chores', NULL),
(60, 3, 'higher_secondary', 'Class funds are being collected for farewell. You…', 'Maintain the full collection sheet', 'Bargain with decorators and photographers', 'Perform on stage', 'Shoot stylish photos for memories', 'Write the farewell speech', NULL),
(61, 22, 'higher_secondary', 'At a career fair, which stall do you visit first?', 'A robotics and drone demo', 'Medical college guidance', 'A fashion institute portfolio wall', 'A law university moot-court video', 'A hotel management live counter', NULL),
(62, 7, 'higher_secondary', 'Low marks in one pre-board subject. Your reaction?', 'Analyse the paper question by question', 'Ask the topper to teach you daily', 'Redesign your study timetable with colours', 'Talk it out with a trusted teacher', 'One match break, then bounce back', NULL);

-- 7 Undergraduate questions (ids 63-69; pool already has 44, 45, 46).
INSERT INTO questions (id, category_id, level_group, question_text, option_a, option_b, option_c, option_d, option_e, correct_answer) VALUES
(63, 8, 'undergraduate', 'First-year hostel life. How do you settle in?', 'Fix the wobbly fan and loose switches', 'Decorate the room on a tight budget', 'Cook maggi for the whole floor', 'Track shared expenses on an app', 'Befriend juniors missing home', NULL),
(64, 11, 'undergraduate', 'Which society would you join: coding, theatre, E-cell, NSS or photography?', 'The coding society', 'Theatre and street plays', 'The entrepreneurship cell', 'NSS blood-donation drives', 'Fashion photography walks', NULL),
(65, 10, 'undergraduate', 'No internship this semester break. Plan B?', 'Learn video editing properly', 'Teach school kids in your lane', 'Sell handmade crafts online', 'Join a cleanliness drive', 'Work at a relative''s shop', NULL),
(66, 3, 'undergraduate', 'Bored of mess food. What do you do?', 'Plan a monthly tiffin budget', 'Start a weekend maggi stall', 'Survey 200 students for better menus', 'Run a funny mess-review meme page', 'Grow coriander on the windowsill', NULL),
(67, 1, 'undergraduate', 'A backlog in one subject. What is the strategy?', 'Six-hour library marathons', 'Evening group study daily', 'Formula charts across the wall', 'Ten years of solved papers', 'A morning run to clear the head', NULL),
(68, 27, 'undergraduate', 'Pocket money over, month still left. What now?', 'Design paid birthday videos', 'Lend and track small loans', 'Write down every rupee spent', 'Borrow from a close friend', 'Play matches with cash prizes', NULL),
(69, 8, 'undergraduate', 'The night before the semester exam…', 'Formula sheet till 3 am', 'Teach friends the tough chapter', 'A colour-coded timetable', 'Solved-papers countdown', 'Lights out early and full rest', NULL);

-- 6 Graduate questions (ids 70-75; pool already has 12, 47, 48, 50).
INSERT INTO questions (id, category_id, level_group, question_text, option_a, option_b, option_c, option_d, option_e, correct_answer) VALUES
(70, 7, 'graduate', 'Last semester plus placement season. What is the priority?', 'Aptitude mocks every day', 'GD-PI practice with friends', 'Resume projects that actually run', 'LinkedIn and alumni networking', 'Staying fit so interviews don''t drain you', NULL),
(71, 3, 'graduate', 'Two offers: MNC versus startup. How do you choose?', 'Compare the salary structures', 'A pros-and-cons accounts sheet', 'Advice from working seniors', 'Gut feeling after a night''s sleep', 'A government-exam backup plan', NULL),
(72, 28, 'graduate', 'The first salary arrives. What does month one look like?', 'Support family back home', 'Good tools for your craft', 'A fixed investment from day one', 'A treat for the whole gang', 'Fixing up your rented room', NULL),
(73, 25, 'graduate', 'The boss assigns boring data cleaning. You…', 'Automate it with a small script', 'Make the sheet beautiful and clear', 'Finish fast, ask for people-facing work', 'Split it fairly with teammates', 'Hit the gym after work to unplug', NULL),
(74, 27, 'graduate', 'Wedding season with friends'' functions. You…', 'Handle the sangeet playlist and sound', 'Track gift money and expenses', 'Be the stylish one in every photo', 'Own the dance floor', 'Drop relatives home safely', NULL),
(75, 24, 'graduate', 'Where do you see yourself one year from now?', 'A patent filed in your name', 'A side business that earns', 'Preparing for judiciary exams', 'A known face making content online', 'Mentoring juniors in your field', NULL);

-- 7 Postgraduate questions (ids 76-82; pool already has 28, 49, 51).
INSERT INTO questions (id, category_id, level_group, question_text, option_a, option_b, option_c, option_d, option_e, correct_answer) VALUES
(76, 1, 'postgraduate', 'Thesis topic stuck between two ideas. How do you decide?', 'A pilot experiment on both', 'A survey of a hundred people', 'Funding and scope first', 'Long talks with lab mates', 'Proper rest, then a fresh call', NULL),
(77, 17, 'postgraduate', 'Presenting a paper at a conference. You…', 'Rehearse till the flow is smooth', 'Redesign every slide beautifully', 'Triple-check every citation', 'Network with professors after', 'Explore the host city on foot', NULL),
(78, 15, 'postgraduate', 'Stipend delayed this month. How do you survive?', 'Part-time tuition work', 'Freelance editing gigs', 'Borrow from a friend', 'A strict no-spend month', 'Extra lab hours for overtime', NULL),
(79, 26, 'postgraduate', 'Things sour with your guide. What do you do?', 'Request an official change', 'Publish a short note alone', 'Seek seniors'' mediation', 'Document everything in writing', 'A weekend trek to reset', NULL),
(80, 15, 'postgraduate', 'Placement versus PhD abroad. How do you break the tie?', 'Advice from three professors', 'A spreadsheet of costs and returns', 'Stories of seniors in jobs', 'A session with the counsellor', 'The subject that excites you most', NULL),
(81, 25, 'postgraduate', 'First week in a new city, in a rented room. You…', 'Set up Wi-Fi and all devices', 'Style the room on a budget', 'Map the ATM, clinic and bus stop', 'Introduce yourself to neighbours', 'Join weekend football with locals', NULL),
(82, 28, 'postgraduate', 'Thesis submitted. How do you celebrate?', 'Call your parents first', 'A party for the lab mates', 'A quiet solo trip', 'A small gift for yourself', 'Start the next paper already', NULL);

-- Weights for the 31 new questions (primary 5, related secondary 2).
INSERT INTO question_option_weights (question_id, option_letter, category_id, weight) VALUES
-- Q52
(52,'A',8,5),(52,'A',11,2),
(52,'B',20,5),(52,'B',1,2),
(52,'C',10,5),(52,'C',13,2),
(52,'D',18,5),
(52,'E',17,5),
-- Q53
(53,'A',13,5),
(53,'B',27,5),(53,'B',13,2),
(53,'C',6,5),
(53,'D',7,5),
(53,'E',18,5),
-- Q54
(54,'A',2,5),
(54,'B',17,5),
(54,'C',7,5),(54,'C',6,2),
(54,'D',28,5),
(54,'E',1,5),
-- Q55
(55,'A',26,5),
(55,'B',13,5),
(55,'C',8,5),
(55,'D',6,5),
(55,'E',17,5),
-- Q56
(56,'A',3,5),
(56,'B',1,5),
(56,'C',13,5),
(56,'D',12,5),
(56,'E',28,5),
-- Q57
(57,'A',24,5),
(57,'B',10,5),
(57,'C',6,5),
(57,'D',8,5),
(57,'E',7,5),
-- Q58
(58,'A',8,5),(58,'A',1,2),
(58,'B',2,5),(58,'B',3,2),
(58,'C',13,5),
(58,'D',9,5),(58,'D',26,2),
(58,'E',19,5),(58,'E',15,2),
-- Q59
(59,'A',7,5),
(59,'B',27,5),
(59,'C',6,5),
(59,'D',16,5),(59,'D',13,2),
(59,'E',12,5),
-- Q60
(60,'A',3,5),
(60,'B',14,5),
(60,'C',27,5),
(60,'D',21,5),(60,'D',5,2),
(60,'E',17,5),
-- Q61
(61,'A',22,5),(61,'A',8,2),
(61,'B',23,5),(61,'B',4,2),
(61,'C',21,5),
(61,'D',9,5),
(61,'E',12,5),
-- Q62
(62,'A',7,5),
(62,'B',15,5),
(62,'C',18,5),
(62,'D',19,5),
(62,'E',6,5),
-- Q63
(63,'A',8,5),
(63,'B',18,5),(63,'B',13,2),
(63,'C',12,5),
(63,'D',2,5),
(63,'E',19,5),
-- Q64
(64,'A',11,5),
(64,'B',27,5),
(64,'C',14,5),
(64,'D',4,5),(64,'D',28,2),
(64,'E',21,5),
-- Q65
(65,'A',10,5),
(65,'B',15,5),
(65,'C',16,5),(65,'C',13,2),
(65,'D',28,5),
(65,'E',14,5),
-- Q66
(66,'A',3,5),
(66,'B',12,5),
(66,'C',7,5),
(66,'D',17,5),
(66,'E',20,5),
-- Q67
(67,'A',1,5),
(67,'B',19,5),
(67,'C',13,5),
(67,'D',7,5),
(67,'E',6,5),
-- Q68
(68,'A',27,5),(68,'A',16,2),
(68,'B',3,5),
(68,'C',2,5),
(68,'D',28,5),
(68,'E',6,5),
-- Q69
(69,'A',8,5),
(69,'B',19,5),
(69,'C',13,5),
(69,'D',7,5),
(69,'E',4,5),
-- Q70
(70,'A',7,5),
(70,'B',17,5),
(70,'C',8,5),
(70,'D',14,5),
(70,'E',6,5),
-- Q71
(71,'A',3,5),
(71,'B',2,5),
(71,'C',15,5),
(71,'D',19,5),
(71,'E',26,5),
-- Q72
(72,'A',28,5),
(72,'B',13,5),
(72,'C',3,5),
(72,'D',12,5),
(72,'E',18,5),
-- Q73
(73,'A',25,5),(73,'A',11,2),
(73,'B',13,5),
(73,'C',17,5),
(73,'D',28,5),
(73,'E',4,5),
-- Q74
(74,'A',27,5),
(74,'B',2,5),
(74,'C',21,5),
(74,'D',6,5),
(74,'E',22,5),(74,'E',12,2),
-- Q75
(75,'A',24,5),(75,'A',8,2),
(75,'B',14,5),
(75,'C',9,5),
(75,'D',16,5),
(75,'E',15,5),
-- Q76
(76,'A',1,5),(76,'A',24,2),
(76,'B',7,5),
(76,'C',3,5),
(76,'D',19,5),
(76,'E',4,5),
-- Q77
(77,'A',17,5),
(77,'B',13,5),
(77,'C',9,5),
(77,'D',14,5),
(77,'E',12,5),
-- Q78
(78,'A',15,5),
(78,'B',10,5),
(78,'C',28,5),
(78,'D',3,5),
(78,'E',8,5),
-- Q79
(79,'A',26,5),
(79,'B',24,5),
(79,'C',28,5),
(79,'D',9,5),
(79,'E',6,5),
-- Q80
(80,'A',15,5),
(80,'B',2,5),
(80,'C',14,5),
(80,'D',19,5),
(80,'E',1,5),
-- Q81
(81,'A',25,5),
(81,'B',21,5),
(81,'C',22,5),
(81,'D',28,5),
(81,'E',6,5),
-- Q82
(82,'A',28,5),
(82,'B',12,5),
(82,'C',22,5),
(82,'D',5,5),(82,'D',21,2),
(82,'E',24,5);
