-- =========================================================
-- NEXTPath migration v3: interest-based weighted assessment
-- Replaces the old right/wrong quiz model with a career-counselling
-- model where every answer option carries weights toward career fields.
-- =========================================================

USE nextpath;

-- 1. Schema: allow a 5th option, retire the "correct answer" column,
--    allow E in stored answers, add the per-option weights table.
-- (Portable: works on MySQL 5.7/8 as well as MariaDB, and is safe to re-run.)
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'questions' AND COLUMN_NAME = 'option_e');
SET @ddl := IF(@col_exists = 0,
    'ALTER TABLE questions ADD COLUMN option_e VARCHAR(255) NULL AFTER option_d',
    'SELECT 1');
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- correct_answer is no longer used for scoring; keep the column for
-- backwards compatibility but allow NULL for new rows.
-- (Wrapped in a procedure-free, idempotent way: ignore errors if already nullable.)
-- MySQL/MariaDB: MODIFY to allow NULL
ALTER TABLE questions MODIFY correct_answer ENUM('A','B','C','D','E') NULL;

ALTER TABLE assessment_answers MODIFY selected_answer ENUM('A','B','C','D','E') NOT NULL;

CREATE TABLE IF NOT EXISTS question_option_weights (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    question_id   INT NOT NULL,
    option_letter ENUM('A','B','C','D','E') NOT NULL,
    category_id   INT NOT NULL,
    weight        TINYINT NOT NULL DEFAULT 5,
    CONSTRAINT uq_qow UNIQUE (question_id, option_letter, category_id),
    CONSTRAINT fk_qow_q FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
    CONSTRAINT fk_qow_c FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 2. Assessment length: the new bank holds 35 questions.
INSERT INTO settings (setting_key, setting_value) VALUES ('assessment_length', '35')
ON DUPLICATE KEY UPDATE setting_value = '35';

-- 3. Clear data scored under the old model (it is mathematically
--    incompatible: old rows measured right/wrong, new rows measure interests).
DELETE FROM assessment_answers;
DELETE FROM assessments;
DELETE FROM question_option_weights;
DELETE FROM questions;

-- 4. New question bank: 35 varied, non-repetitive counselling questions.
--    Letters are deliberately rotated so A/B/C/D/E never consistently mean
--    the same field. Option E is NULL on four questions for 4/5 variety.
--    Categories: 1 Science, 2 Accounting & Finance, 3 Banking,
--    4 Nursing & Healthcare, 5 Beauty & Wellness, 6 Fitness & Sports,
--    7 Data Science, 8 Engineering, 9 Law, 10 Animation,
--    11 Information Technology, 12 Hospitality & Tourism, 13 Arts & Design,
--    14 Business & Management, 15 Teaching & Education, 16 Digital Marketing,
--    17 Media & Journalism, 18 Architecture, 19 Psychology & Human Services,
--    20 Agriculture & Environmental Science, 21 Fashion, 22 Aviation,
--    23 Pharmacy, 24 Biotechnology, 25 Cybersecurity,
--    26 Government & Public Administration, 27 Film & Photography, 28 Social Work.

INSERT INTO questions (id, category_id, question_text, option_a, option_b, option_c, option_d, option_e, correct_answer) VALUES
(1, 11, 'It is a free Saturday with no plans. What are you most likely to end up doing?', 'Building a small app or automating something on your laptop', 'Sketching, doodling or editing photos', 'Organising a get-together and giving everyone a role', 'Listening to a friend who is going through a tough time', 'Reviewing your spending and planning next month''s budget', NULL),
(2, 15, 'In a team project, which role do you naturally take?', 'Mentoring teammates who get stuck', 'Researching facts and testing what actually works', 'Designing how the final output should look and feel', 'Presenting the idea and persuading the audience', 'Setting the timeline and keeping everyone on track', NULL),
(3, 4, 'Which problem would you enjoy tackling for a whole week?', 'Supporting patients through recovery in a busy ward', 'Tracing how a network was breached and closing the gap', 'Designing a poster that makes people stop and look', 'Planning how public funds should reach villages', 'Finding the story hidden in a pile of sales figures', NULL),
(4, 3, 'Pick a weekend workshop to attend.', 'How money grows: savings, credit and banking basics', 'How machines work: a hands-on robotics trial', 'How films are made: shooting and editing a short scene', 'How medicines work: first aid and safe dosage', 'How arguments win: speaking and reasoning under pressure', NULL),
(5, 21, 'Your friends ask you for help most often with…', 'Choosing an outfit or hairstyle for an occasion', 'Fixing a phone, laptop or Wi-Fi issue', 'Figuring out whether they can afford something', 'Understanding a tough chapter before exams', 'Sticking to a workout or diet plan', NULL),
(6, 27, 'Which headline would you click first?', 'Box-office record broken by a debut director', 'New AI model that predicts disease early', 'Startup raises funds to expand to three cities', 'River-cleaning drive revives local farming', 'Underdog team wins the national final', NULL),
(7, 7, 'Which kind of task leaves you energised rather than drained?', 'Finding patterns in numbers and data', 'Making something dull look beautiful', 'Coaching a group toward a tough target', 'Sitting with someone and easing their worry', 'Balancing accounts until every rupee is traced', NULL),
(8, 8, 'How do you usually solve an unfamiliar problem?', 'Break it into parts and test each one physically', 'Look for visual examples and adapt the design', 'Talk it through with people and decide together', 'Check past records and numbers before acting', NULL, NULL),
(9, 12, 'Choose a school club to lead for a year.', 'Hospitality and event crew: hosting guests well', 'Coding club: shipping small working apps', 'Photo and short-film circle', 'Health and first-response volunteers', 'Debate and mock-trial society', NULL),
(10, 26, 'Which compliment would mean the most to you?', 'People say they trust your judgement in public matters', 'Your reasoning is razor-sharp', 'Your taste and style are excellent', 'You genuinely changed someone''s life for the better', 'You handle money more responsibly than anyone', NULL),
(11, 1, 'You must master a difficult new topic. What works best for you?', 'Trying a hands-on experiment yourself', 'Watching a visual explainer or animation', 'Discussing it in a study group', 'Following a precise step-by-step manual', 'Visiting the field to see it in real life', NULL),
(12, 11, 'Pick a two-week internship you would actually enjoy.', 'A software startup shipping a live feature', 'A design studio working on a brand look', 'A bank branch advising real customers', 'A hospital ward assisting the care team', 'A newsroom chasing and filing real stories', NULL),
(13, 28, 'Something breaks down at home. What do you do first?', 'Open it up, diagnose the fault and fix it', 'Redesign the corner so it works better than before', 'Call the right person and coordinate the repair', 'Compare repair cost against the household budget', 'Check whether an elderly neighbour needs the same help', NULL),
(14, 2, 'Which mistake bothers you most when you spot it?', 'An unbalanced budget that hides a leak', 'An argument that makes no logical sense', 'A poster or page that looks careless and ugly', 'A rule that treats people unfairly', 'A news report that gets its facts wrong', NULL),
(15, 22, 'Which tool would you happily spend months mastering?', 'A flight simulator and navigation charts', 'A data dashboard dealing with lakhs of rows', 'A cinema-grade video editing setup', 'A planner used to run a 200-room hotel', 'A dispensary kit with testing and dosage tools', NULL),
(16, 19, 'How do you handle a disagreement inside your group?', 'Sit with each person privately and hear them out', 'Lay out the logic and evidence calmly', 'Sketch a creative middle path nobody thought of', 'Put it to a quick vote and move on', NULL, NULL),
(17, 25, 'What motivates you most at work?', 'Outsmarting an attacker and securing a system', 'Seeing your original creation loved by strangers', 'Growing a small venture into a big employer', 'Watching a patient walk out healthier', 'Building steady, secure savings for family', NULL),
(18, 24, 'Pick a book to carry on a long holiday.', 'The gene-editing revolution, explained simply', 'Sketches and notes of an iconic fashion house', 'How a small brand used the internet to win big', 'Letters on grief, growth and becoming yourself', 'Twelve famous trials that changed the law', NULL),
(19, 20, 'How would you prefer to spend most workdays?', 'Outdoors with crops, soil and livestock', 'In a laboratory testing samples', 'On a site where structures come up', 'In a studio shaping images and objects', 'Among guests, travellers and new faces', NULL),
(20, 7, 'A deadline is 48 hours away and the work is half-done. What do you do first?', 'List assumptions and test the riskiest one fast', 'Draw a rough version so the team can react', 'Split the work and give every person one owner', 'Calm everyone down and check who is struggling', 'Work out exactly what can be afforded', NULL),
(21, 9, 'Which impact matters most to you personally?', 'Protecting people''s rights through fair process', 'Pushing human knowledge one step forward', 'Shaping what millions watch, read and wear', 'Creating jobs that feed families', 'Helping the sick afford the right treatment', NULL),
(22, 15, 'Choose volunteer work for one month.', 'Teaching children on weekends', 'Assisting in a rural health camp', 'Planting and reviving a neighbourhood green patch', 'Running the accounts of a charity drive', NULL, NULL),
(23, 12, 'How would you plan a trip for ten friends?', 'Handling bookings, rooms and on-ground coordination', 'Hunting cheap flights and the smartest route', 'Shooting it as a short travel film', 'Modelling costs per person in a sheet', 'Comparing past trip data to pick the best week', NULL),
(24, 11, 'Pick a part-time job you would genuinely enjoy.', 'A computer-repair desk for students', 'A salon assisting with hair and skin care', 'Evening tuition for younger students', 'Assisting a coach at a neighbourhood gym', 'Coordinating deliveries and stays for guests', NULL),
(25, 6, 'After an exhausting month, what truly recharges you?', 'Tinkering with a gadget or small engine', 'A weekend of films, music and galleries', 'Long hours with family and community', 'Early-morning training, sport and sweat', 'Slow reading and your own small research notes', NULL),
(26, 14, 'What kind of mentor do you wish you had?', 'A founder who built a company from zero', 'A scientist whose discovery saved lives', 'A senior nurse who never panics', 'A master artist with unmistakable style', 'A judge known for fearless fairness', NULL),
(27, 3, 'How do you usually make an important decision?', 'Weighing interest, risk and return on money', 'Gathering data and comparing options coldly', 'Sketching how each choice could look and feel', 'Calling two experienced people you trust', 'Asking who gets hurt and who gets helped', NULL),
(28, 23, 'In college, which session would you never bunk?', 'Dispensing practice: dosage, safety and counselling', 'A live newsroom simulation with deadlines', 'Tallying a real company''s books line by line', 'A soil-and-seed walk on a working farm', 'Drafting and raising a small pavilion model', NULL),
(29, 1, 'What would you proudly add to your portfolio?', 'A research note with a finding nobody reported', 'A working website people can actually use', 'A short film that played at a student festival', 'A tiny business that already earns profit', 'A community project that helped fifty families', NULL),
(30, 13, 'How would your closest friends describe you?', 'The creative one with original ideas', 'The fixer who solves anything technical', 'The organiser everyone relies on', 'The listener people trust with feelings', NULL, NULL),
(31, 7, 'Choose what to work with every single day.', 'Rows of data hiding useful patterns', 'Machines, engines and tools', 'Frames, colours and moving images', 'Deposits, loans and market moves', 'Patients who need patience and care', NULL),
(32, 14, 'How do you feel about taking risks?', 'Happy to risk capital on a venture that could scale', 'Happy to bet on a tricky technical defence', 'Happy to experiment with a bold new look', 'Prefer steady mentoring work with young people', 'Prefer a safe, well-paid role in finance', NULL),
(33, 26, 'In five years, what does success look like?', 'Leading a department that serves the public well', 'Holding a patent or discovery with your name', 'Premieres with your name in the credits', 'Running a firm with forty employees', 'Being the neighbour everyone calls in a crisis', NULL),
(34, 19, 'Which failure would sting you the longest?', 'Breaking the trust people placed in you', 'A flaw in your logic everyone can see', 'A design people call tasteless', 'Money lost through your carelessness', 'A patient harmed because you rushed', NULL),
(35, 16, 'Pick one competition to enter next month.', 'A business-pitch contest with real investors', 'A national hackathon with overnight coding', 'A streetwear design battle', 'A science olympiad with lab rounds', 'An inter-college athletics meet', NULL);

-- 5. Weights: each option points at its field with 5; closely related
--    fields get a secondary 2. Letters are balanced by construction.
INSERT INTO question_option_weights (question_id, option_letter, category_id, weight) VALUES
-- Q1
(1,'A',11,5),(1,'A',25,2),
(1,'B',13,5),(1,'B',27,2),
(1,'C',14,5),(1,'C',26,2),
(1,'D',19,5),(1,'D',28,2),
(1,'E',2,5),(1,'E',3,2),
-- Q2
(2,'A',15,5),(2,'A',19,2),
(2,'B',1,5),(2,'B',24,2),
(2,'C',10,5),(2,'C',13,2),
(2,'D',17,5),(2,'D',16,2),
(2,'E',12,5),(2,'E',14,2),
-- Q3
(3,'A',4,5),(3,'A',23,2),
(3,'B',25,5),(3,'B',11,2),
(3,'C',13,5),(3,'C',10,2),
(3,'D',26,5),(3,'D',9,2),
(3,'E',7,5),(3,'E',11,2),
-- Q4
(4,'A',3,5),(4,'A',2,2),
(4,'B',8,5),(4,'B',1,2),
(4,'C',27,5),(4,'C',17,2),
(4,'D',23,5),(4,'D',4,2),
(4,'E',9,5),(4,'E',26,2),
-- Q5
(5,'A',21,5),(5,'A',5,2),
(5,'B',11,5),
(5,'C',2,5),(5,'C',3,2),
(5,'D',15,5),
(5,'E',6,5),(5,'E',4,2),
-- Q6
(6,'A',27,5),(6,'A',17,2),
(6,'B',7,5),(6,'B',24,2),
(6,'C',14,5),(6,'C',16,2),
(6,'D',20,5),(6,'D',1,2),
(6,'E',6,5),
-- Q7
(7,'A',7,5),(7,'A',25,2),
(7,'B',13,5),(7,'B',21,2),
(7,'C',6,5),(7,'C',14,2),
(7,'D',19,5),(7,'D',4,2),
(7,'E',2,5),
-- Q8 (4 options)
(8,'A',8,5),(8,'A',18,2),
(8,'B',13,5),(8,'B',10,2),
(8,'C',15,5),(8,'C',19,2),
(8,'D',3,5),(8,'D',7,2),
-- Q9
(9,'A',12,5),(9,'A',22,2),
(9,'B',11,5),
(9,'C',27,5),(9,'C',10,2),
(9,'D',4,5),
(9,'E',9,5),(9,'E',26,2),
-- Q10
(10,'A',26,5),(10,'A',14,2),
(10,'B',1,5),(10,'B',7,2),
(10,'C',13,5),(10,'C',21,2),
(10,'D',28,5),(10,'D',19,2),
(10,'E',2,5),(10,'E',3,2),
-- Q11
(11,'A',1,5),(11,'A',24,2),
(11,'B',10,5),(11,'B',27,2),
(11,'C',15,5),(11,'C',19,2),
(11,'D',8,5),
(11,'E',20,5),(11,'E',1,2),
-- Q12
(12,'A',11,5),(12,'A',25,2),
(12,'B',13,5),(12,'B',16,2),
(12,'C',3,5),
(12,'D',4,5),(12,'D',23,2),
(12,'E',17,5),
-- Q13
(13,'A',8,5),
(13,'B',18,5),(13,'B',13,2),
(13,'C',12,5),(13,'C',14,2),
(13,'D',2,5),
(13,'E',28,5),(13,'E',19,2),
-- Q14
(14,'A',2,5),(14,'A',3,2),
(14,'B',1,5),(14,'B',7,2),
(14,'C',13,5),
(14,'D',26,5),(14,'D',9,2),
(14,'E',17,5),(14,'E',27,2),
-- Q15
(15,'A',22,5),(15,'A',8,2),
(15,'B',7,5),
(15,'C',27,5),(15,'C',10,2),
(15,'D',12,5),(15,'D',14,2),
(15,'E',23,5),(15,'E',4,2),
-- Q16 (4 options)
(16,'A',19,5),(16,'A',28,2),
(16,'B',1,5),
(16,'C',13,5),(16,'C',21,2),
(16,'D',14,5),(16,'D',26,2),
-- Q17
(17,'A',25,5),(17,'A',11,2),
(17,'B',10,5),(17,'B',13,2),
(17,'C',14,5),
(17,'D',4,5),(17,'D',19,2),
(17,'E',3,5),(17,'E',2,2),
-- Q18
(18,'A',24,5),(18,'A',1,2),
(18,'B',21,5),(18,'B',5,2),
(18,'C',16,5),(18,'C',14,2),
(18,'D',19,5),
(18,'E',9,5),
-- Q19
(19,'A',20,5),
(19,'B',1,5),(19,'B',23,2),
(19,'C',8,5),(19,'C',18,2),
(19,'D',13,5),(19,'D',10,2),
(19,'E',12,5),
-- Q20
(20,'A',7,5),(20,'A',11,2),
(20,'B',18,5),(20,'B',13,2),
(20,'C',14,5),(20,'C',12,2),
(20,'D',19,5),
(20,'E',2,5),(20,'E',3,2),
-- Q21
(21,'A',9,5),(21,'A',26,2),
(21,'B',1,5),
(21,'C',17,5),(21,'C',27,2),
(21,'D',14,5),(21,'D',3,2),
(21,'E',23,5),(21,'E',4,2),
-- Q22 (4 options)
(22,'A',15,5),
(22,'B',4,5),(22,'B',28,2),
(22,'C',20,5),(22,'C',24,2),
(22,'D',2,5),(22,'D',28,2),
-- Q23
(23,'A',12,5),(23,'A',14,2),
(23,'B',22,5),(23,'B',7,2),
(23,'C',27,5),
(23,'D',2,5),(23,'D',3,2),
(23,'E',7,5),
-- Q24
(24,'A',11,5),(24,'A',25,2),
(24,'B',5,5),(24,'B',21,2),
(24,'C',15,5),
(24,'D',6,5),
(24,'E',12,5),(24,'E',22,2),
-- Q25
(25,'A',8,5),(25,'A',11,2),
(25,'B',27,5),(25,'B',13,2),
(25,'C',28,5),
(25,'D',6,5),(25,'D',4,2),
(25,'E',1,5),(25,'E',7,2),
-- Q26
(26,'A',14,5),(26,'A',3,2),
(26,'B',24,5),(26,'B',1,2),
(26,'C',4,5),
(26,'D',13,5),(26,'D',10,2),
(26,'E',9,5),(26,'E',26,2),
-- Q27
(27,'A',3,5),(27,'A',2,2),
(27,'B',7,5),
(27,'C',13,5),(27,'C',18,2),
(27,'D',15,5),(27,'D',26,2),
(27,'E',19,5),(27,'E',28,2),
-- Q28
(28,'A',23,5),
(28,'B',17,5),(28,'B',16,2),
(28,'C',2,5),
(28,'D',20,5),(28,'D',1,2),
(28,'E',18,5),(28,'E',8,2),
-- Q29
(29,'A',1,5),(29,'A',7,2),
(29,'B',11,5),
(29,'C',27,5),(29,'C',17,2),
(29,'D',14,5),(29,'D',16,2),
(29,'E',28,5),(29,'E',19,2),
-- Q30 (4 options)
(30,'A',13,5),(30,'A',10,2),
(30,'B',8,5),(30,'B',25,2),
(30,'C',14,5),
(30,'D',19,5),(30,'D',15,2),
-- Q31
(31,'A',7,5),
(31,'B',8,5),(31,'B',22,2),
(31,'C',10,5),(31,'C',27,2),
(31,'D',3,5),(31,'D',2,2),
(31,'E',4,5),(31,'E',28,2),
-- Q32
(32,'A',14,5),(32,'A',16,2),
(32,'B',25,5),
(32,'C',21,5),(32,'C',13,2),
(32,'D',15,5),(32,'D',19,2),
(32,'E',3,5),
-- Q33
(33,'A',26,5),
(33,'B',24,5),(33,'B',1,2),
(33,'C',27,5),
(33,'D',14,5),(33,'D',12,2),
(33,'E',28,5),(33,'E',19,2),
-- Q34
(34,'A',19,5),(34,'A',14,2),
(34,'B',7,5),(34,'B',1,2),
(34,'C',13,5),
(34,'D',2,5),
(34,'E',4,5),(34,'E',23,2),
-- Q35
(35,'A',16,5),(35,'A',14,2),
(35,'B',11,5),(35,'B',25,2),
(35,'C',21,5),
(35,'D',1,5),(35,'D',24,2),
(35,'E',6,5);
