-- =========================================================
-- NEXTPath migration v4: education-level-wise question sets
-- School (High School, Higher Secondary) and College
-- (Undergraduate, Graduate, Postgraduate) students now get
-- different selections: level-specific questions first, then
-- shared general questions to fill the assessment length.
-- Scoring is unchanged (question_option_weights).
-- =========================================================

USE nextpath;

-- (Portable: works on MySQL 5.7/8 as well as MariaDB, and is safe to re-run.)
SET @col_exists := (SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'questions' AND COLUMN_NAME = 'level_group');
SET @ddl := IF(@col_exists = 0,
    'ALTER TABLE questions ADD COLUMN level_group ENUM(''all'',''school'',''college'') NOT NULL DEFAULT ''all''',
    'SELECT 1');
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- A few existing questions clearly belong to one world; retag them.
UPDATE questions SET level_group = 'school'  WHERE id = 9;
UPDATE questions SET level_group = 'college' WHERE id IN (12, 28);

-- 8 school-context questions (ids 36-43).
INSERT INTO questions (id, category_id, level_group, question_text, option_a, option_b, option_c, option_d, option_e, correct_answer) VALUES
(36, 1, 'school', 'Which school activity would you never want to miss?', 'Testing things yourself in the lab practical', 'Giving trials for inter-school sports', 'The art-and-craft period', 'Debate or elocution practice', 'The maths puzzle club', NULL),
(37, 18, 'school', 'You get charge of the school annual function. What do you take up?', 'Stage decoration and the backdrop', 'Anchoring the whole show', 'Ticket money and the expense register', 'Guest seating and food stalls', 'Training juniors for the group dance', NULL),
(38, 11, 'school', 'Board exams just ended and you have one free month. What first?', 'Learning coding basics online', 'Joining a sketching and drawing course', 'A cricket or athletics summer camp', 'Volunteering to teach younger kids', 'Reading about space, robots and inventions', NULL),
(39, 16, 'school', 'Teachers pick you first for which kind of work?', 'Designing the class presentation slides', 'Solving the toughest sums on the board', 'Anchoring the assembly or events', 'Handling class funds and attendance', 'Helping classmates who are weak in studies', NULL),
(40, 22, 'school', 'How would you plan the class picnic?', 'Finding the cheapest buses and the best route', 'Listing games and sports for the day', 'Collecting money and tracking every rupee', 'Writing the permission letter to the principal', 'Shooting a fun video of the whole trip', NULL),
(41, 3, 'school', 'What does your pocket-money habit say about you?', 'You save a fixed part every month', 'You spend it on books and DIY kits', 'You spend it on hairstyles and new looks', 'You never forget friends'' birthdays and gifts', 'You compare prices online before buying anything', NULL),
(42, 24, 'school', 'Which competition excites you most?', 'A science olympiad', 'A best-out-of-waste design contest', 'A street play on a social issue', 'An essay-writing contest', 'A chess tournament', NULL),
(43, 12, 'school', 'A new student joins your class. What do you do?', 'Show them the labs, library and classrooms', 'Help them catch up in tough subjects', 'Introduce them to your sports group', 'Make sure they feel included from day one', 'Enter their details in the class register', NULL);

-- 8 college-context questions (ids 44-51).
INSERT INTO questions (id, category_id, level_group, question_text, option_a, option_b, option_c, option_d, option_e, correct_answer) VALUES
(44, 8, 'college', 'Your college fest needs volunteers. Where do you sign up?', 'Stage sound, lights and technical setup', 'Social-media promotions and posters', 'Bringing sponsors and handling the cash', 'Receiving guests and managing stalls', 'Compering the main night on stage', NULL),
(45, 25, 'college', 'Which contest would you enter: hackathon, pitch, moot court, design sprint or quiz?', 'An overnight hackathon', 'A business-plan pitch to investors', 'A moot-court argument', 'A UI design sprint', 'An inter-college quiz bowl', NULL),
(46, 27, 'college', 'You need part-time income this semester. What do you pick?', 'Freelance poster and video edits', 'Home tuitions for school kids', 'Food-delivery or event-crew shifts', 'Being a campus ambassador for a brand', 'Back-office and records work', NULL),
(47, 11, 'college', 'Which company queue would you join first on placement day?', 'A software product startup', 'A leading bank', 'A creative advertising agency', 'An NGO with field work', 'A hospital or pharma company', NULL),
(48, 8, 'college', 'Final year: higher studies, job, startup, or sarkari exam?', 'M.Tech or MS through GATE or GRE', 'CAT preparation and the MBA dream', 'UPSC or SSC preparation', 'A design portfolio for a design school', 'Starting as a full-time video creator', NULL),
(49, 24, 'college', 'A professor offers you a project. Which one do you grab?', 'Lab research with real samples', 'A village survey on water and crops', 'Testing the campus portal''s security', 'A market survey for a local shop', 'Documenting the project as a short film', NULL),
(50, 6, 'college', 'How do you spend a three-day weekend with friends?', 'A trek or a long bike ride', 'Exploring street food and local markets', 'A styled photoshoot at a scenic spot', 'A science museum or planetarium visit', 'Keeping the trip budget for the whole group', NULL),
(51, 8, 'college', 'What would you build in your final year?', 'A working robot or IoT device', 'A small venture that already earns', 'A free legal-aid clinic project', 'A fashion lookbook', 'A community health drive', NULL);

-- Weights for the 16 new questions (primary 5, related secondary 2).
INSERT INTO question_option_weights (question_id, option_letter, category_id, weight) VALUES
-- Q36
(36,'A',1,5),(36,'A',24,2),
(36,'B',6,5),
(36,'C',13,5),(36,'C',21,2),
(36,'D',17,5),(36,'D',9,2),
(36,'E',7,5),(36,'E',8,2),
-- Q37
(37,'A',18,5),(37,'A',13,2),
(37,'B',17,5),(37,'B',27,2),
(37,'C',2,5),
(37,'D',12,5),(37,'D',14,2),
(37,'E',15,5),(37,'E',6,2),
-- Q38
(38,'A',11,5),(38,'A',25,2),
(38,'B',10,5),(38,'B',13,2),
(38,'C',6,5),
(38,'D',28,5),(38,'D',15,2),
(38,'E',8,5),(38,'E',1,2),
-- Q39
(39,'A',16,5),(39,'A',13,2),
(39,'B',7,5),
(39,'C',27,5),(39,'C',17,2),
(39,'D',3,5),
(39,'E',15,5),
-- Q40
(40,'A',22,5),(40,'A',12,2),
(40,'B',6,5),
(40,'C',2,5),
(40,'D',9,5),(40,'D',26,2),
(40,'E',27,5),
-- Q41
(41,'A',3,5),
(41,'B',1,5),
(41,'C',5,5),(41,'C',21,2),
(41,'D',28,5),
(41,'E',7,5),(41,'E',3,2),
-- Q42
(42,'A',24,5),(42,'A',1,2),
(42,'B',18,5),(42,'B',13,2),
(42,'C',28,5),(42,'C',17,2),
(42,'D',17,5),
(42,'E',7,5),
-- Q43
(43,'A',12,5),
(43,'B',15,5),
(43,'C',6,5),
(43,'D',19,5),
(43,'E',26,5),
-- Q44
(44,'A',8,5),(44,'A',11,2),
(44,'B',16,5),(44,'B',13,2),
(44,'C',14,5),(44,'C',3,2),
(44,'D',12,5),
(44,'E',27,5),(44,'E',17,2),
-- Q45
(45,'A',25,5),(45,'A',11,2),
(45,'B',14,5),
(45,'C',9,5),
(45,'D',10,5),(45,'D',18,2),
(45,'E',1,5),(45,'E',7,2),
-- Q46
(46,'A',27,5),(46,'A',10,2),
(46,'B',15,5),
(46,'C',12,5),(46,'C',14,2),
(46,'D',16,5),
(46,'E',3,5),
-- Q47
(47,'A',11,5),
(47,'B',3,5),
(47,'C',17,5),(47,'C',27,2),
(47,'D',28,5),(47,'D',20,2),
(47,'E',23,5),(47,'E',4,2),
-- Q48
(48,'A',8,5),(48,'A',1,2),
(48,'B',14,5),
(48,'C',26,5),(48,'C',9,2),
(48,'D',21,5),
(48,'E',27,5),(48,'E',16,2),
-- Q49
(49,'A',24,5),(49,'A',23,2),
(49,'B',20,5),(49,'B',28,2),
(49,'C',25,5),
(49,'D',7,5),
(49,'E',17,5),
-- Q50
(50,'A',6,5),
(50,'B',12,5),
(50,'C',5,5),(50,'C',21,2),
(50,'D',1,5),
(50,'E',2,5),
-- Q51
(51,'A',8,5),
(51,'B',2,5),(51,'B',3,2),
(51,'C',9,5),
(51,'D',21,5),
(51,'E',4,5),(51,'E',28,2);
