# NEXTPath
### Adaptive Skill Assessment &amp; Career Discovery Platform

*Discover Your Skills. Find Your Direction.*

NEXTPath is a full-stack web platform that helps students discover their
strengths and explore matching career paths through an adaptive,
multi-category skill assessment.

---

## Overview

Students create a profile, complete a mixed-category multiple-choice
assessment, and receive a personalised skill profile, strength analysis,
and ranked career recommendations — all calculated from their actual
answers. Administrators manage the question bank, career categories,
career mappings and students through a dedicated Admin Dashboard.

## Features

**Student**
- Registration and login with hashed passwords and server-side validation
- 35-question interest-based assessment (configurable), with varied,
  non-repetitive counselling questions and 4–5 contextual answer options
  per question — no categories shown, no right/wrong answers — presented
  in a distraction-free one-question interface with progress bar and
  Previous/Next navigation
- Education-level-wise sets: each of High School, Higher Secondary,
  Undergraduate, Graduate and Postgraduate gets its own 10 level-specific
  questions (school-life, coaching, hostel, placement, thesis contexts),
  filled from the shared general set to 35 (level-specific first, then
  general, shuffled)
- Real, calculated field-affinity scoring: every selected answer adds its
  predefined weights to the relevant career fields, converted to
  earned ÷ maximum-possible percentages per field (repeating one letter
  can never yield 100% everywhere, because letters map to different
  fields on different questions)
- Skill Profile derived from field affinity (Analytical Thinking,
  Problem Solving, Technical Aptitude, Communication, Creativity, Leadership)
- Strength Analysis ranking the student's strongest areas
- Multiple ranked Career Recommendations with match percentages
  (highest to lowest; unrelated fields stay low)
- Career Dashboard with field-affinity bars (pure CSS, no chart libs)
- Assessment History across every attempt
- Editable profile (interests, skills, hobbies, education, etc.)

**Admin**
- Dashboard with platform-wide totals, recent activity and field coverage
- Full Student directory (no passwords ever shown)
- Full CRUD for Questions (question text + 4–5 options + per-option
  career-field weights), Categories, Careers and Courses
- Career-field filter on the question bank (matches any option pointing there)
- Assessment log across all students
- Statistics: totals, average top match, most pointed-to field, most supported career

**Career Explorer** — a browsable, searchable directory of all 28 career
categories, their mapped careers and suggested courses, independent of
the student's own assessment results.

**College / Course Recommendations** — every career recommendation on the
Career Dashboard and in the downloadable report is paired with real
suggested courses/degrees for that field (e.g. Software Developer →
BCA, B.Tech CS/IT), pulled from the `courses` table so admins can expand
or correct them at any time.

**Downloadable Career Report** — a clean, print-formatted version of a
student's results (`career-report.php`) with a "Print / Save as PDF"
button. It uses the browser's native print-to-PDF rather than a PHP PDF
library, so there's nothing extra to install — it works on any XAMPP
setup out of the box.

## Technology Stack

Strictly:
- **Frontend:** HTML5, CSS3, Vanilla JavaScript (no frameworks, no jQuery, no Bootstrap/Tailwind)
- **Backend:** PHP (PDO, prepared statements throughout)
- **Database:** MySQL / MariaDB

No React, Vue, Angular, Node.js, Python, Laravel, CodeIgniter, Chart.js or
any other framework is used anywhere in this project.

## System Requirements

- PHP 8.0+ with the `pdo_mysql` extension
- MySQL 5.7+ or MariaDB 10.3+
- Apache (via XAMPP/WAMP/LAMP) or the PHP built-in server

## Installation

1. Copy the `nextpath` folder to your web root:
   ```
   C:\xampp\htdocs\nextpath      (Windows/XAMPP)
   /Applications/XAMPP/htdocs/nextpath   (macOS)
   /var/www/html/nextpath        (Linux)
   ```
2. Start **Apache** and **MySQL** from the XAMPP control panel.
3. Open `http://localhost/phpmyadmin` and import **`database/nextpath_full.sql`**
   (single file, creates the database and everything in it — recommended for a
   new install). Alternatively import `database/nextpath.sql` followed by the
   four migrations listed below, in order.
4. If your MySQL root user has a password, update `config/database.php`
   accordingly (defaults to `root` / empty password, XAMPP's default).
5. Visit `http://localhost/nextpath/`.

### Database Setup

`database/nextpath_full.sql` (or `nextpath.sql` plus the four migrations) will, on import:
1. Create the `nextpath` database and all tables
2. Seed 28 career categories (all covered by the weighted question bank)
3. Seed 35 interest-based counselling questions with 4–5 contextual options
   each (`migration_v3_weighted.sql`), every option carrying weights toward
   its career field(s) in `question_option_weights`
4. Seed 84 careers mapped to categories with a relevance weight
5. Seed a category → skill mapping used to build the Skill Profile
6. Seed 56 suggested courses (2 per category) used for College / Course Recommendations
7. Create a sample admin account

**Admin login:** `admin@nextpath.com` / `Admin@123`
(the password hash in the SQL file is a genuine bcrypt hash of this
password, verified against PHP's `password_hash`/`password_verify`).

**Already installed NEXTPath before this update?** You don't need to
re-import everything — just import the migrations in order, the same way
(phpMyAdmin → select the `nextpath` database → Import):
1. `database/migration_v2_courses.sql` (if you haven't already — adds the
   `courses` table and its seed data; nothing existing is touched), then
2. `database/migration_v3_weighted.sql` (converts the assessment to the
   interest-based weighted model: adds `option_e` + `question_option_weights`,
   replaces the 40 quiz questions with 35 counselling questions, and sets
   `assessment_length` to 35), then
3. `database/migration_v4_levels.sql` (adds `questions.level_group` and
   16 level-specific questions: 8 school-context, 8 college-context), then
4. `database/migration_v5_per_level.sql` (one pool per education level:
   10 specific questions each for High School, Higher Secondary,
   Undergraduate, Graduate and Postgraduate; 82 questions total).
> Note: the v3 migration clears previous `assessments` / `assessment_answers`
> rows because scores from the old right/wrong model are mathematically
> incompatible with the new interest model. Student accounts, categories,
> careers and courses are untouched.

## Student Workflow

```
Register → Login → Dashboard → Start Assessment
  → 35 interest-based questions (4–5 contextual options, no right/wrong) → Submit
  → Top Match, Field Affinities, Skill Profile, Strengths
  → Career Recommendations ranked highest-to-lowest (+ Suggested Courses) → Career Dashboard
  → Download Career Report (PDF via browser print) → Assessment History
  → Career Explorer (browse all 28 fields any time)
```

## Admin Workflow

```
Admin Login → Admin Dashboard
  → Students (read-only directory)
  → Questions (create / read / update / delete with per-option field weights, filter by field)
  → Categories (create / read / update / delete)
  → Careers (create / read / update / delete)
  → Courses (create / read / update / delete)
  → Assessments (full log)
  → Statistics
```

## Assessment Algorithm (weighted interest model)

```
Student answers question (no right/wrong, no visible category)
        ↓
Look up the selected option's weights in question_option_weights
        ↓
Store the answer + contributed points in assessment_answers
        ↓
Field Affinity = earned points in field / max points achievable in field × 100
  (max = sum over this assessment's questions of the field's best weight
   per question — so percentages are earned ÷ possible, per field)
        ↓
Top Match = highest field affinity (stored as assessments.overall_score)
        ↓
Skill Profile = weighted average of field affinities per mapped skill
        ↓
Career Match = Field Affinity × Career Relevance
        ↓
Recommendations sorted by match, highest first
```

The whole pipeline lives in `includes/functions.php` so the scoring or
recommendation formula can be changed in one place. Weights themselves live
in the `question_option_weights` table
(`database/migration_v3_weighted.sql`) so admins can re-point any answer
at any field(s) without touching code.

## Career Recommendation System

Every career belongs to one category and carries a `relevance` weight
(0–1) set by the admin. A student's match percentage for that career is
their affinity in the career's field multiplied by that relevance,
capped at 100%. Recommendations across all matched careers are then
sorted highest-to-lowest and the top results are shown. Because affinity
itself is earned ÷ possible per field, repeating one option letter cannot
inflate every career: letters map to different fields on different
questions by design (`database/migration_v3_weighted.sql`).

## Security

- **Passwords:** `password_hash()` / `password_verify()` — never stored in plain text
- **SQL:** PDO prepared statements everywhere; no raw string concatenation into queries
- **XSS:** every piece of user-controlled output is passed through `htmlspecialchars()`
  via the `clean()` helper
- **Authentication:** PHP sessions (`includes/functions.php`)
- **Authorization:** `includes/auth.php` (student-only pages) and
  `includes/admin_auth.php` (admin-only pages) guard every protected page;
  a student can never reach `/admin/*` and is redirected back to their
  own dashboard if they try
- **Error handling:** database exceptions are logged server-side and never
  shown to the user; the user only ever sees "Something went wrong. Please try again."

## Project Structure

```
nextpath/
├── index.php, login.php, register.php, logout.php
├── contact.php, privacy.php, terms.php
├── config/database.php
├── includes/
│   ├── header.php, footer.php          (public site chrome)
│   ├── sidebar.php, admin-sidebar.php   (dashboard navigation)
│   ├── auth.php, admin_auth.php         (route guards)
│   └── functions.php                    (all shared logic)
├── student/
│   ├── dashboard.php, assessment.php, submit_assessment.php
│   ├── result.php, career-dashboard.php, career-report.php, history.php
│   ├── explorer.php
│   └── profile.php, update-profile.php
├── admin/
│   ├── dashboard.php, students.php, assessments.php, statistics.php
│   ├── questions.php, add-question.php, edit-question.php, delete-question.php
│   ├── categories.php, add-category.php, edit-category.php, delete-category.php
│   ├── careers.php, add-career.php, edit-career.php, delete-career.php
│   └── courses.php, add-course.php, edit-course.php, delete-course.php
├── assets/
│   ├── css/ (main, auth, dashboard, assessment, admin, explorer, report)
│   └── js/  (main, assessment, validation, explorer)
└── database/ (nextpath_full.sql, nextpath.sql, migration_v2 … v5)
```

## Design System

- **Typography:** Manrope (headings) / Inter (body), a modern grotesk pairing,
  loaded from Google Fonts with system-font fallbacks so the layout stays
  fully functional if the webfont fails to load
- **Color palette:** off-white background, dark text, restrained navy/green
  accents (`#1F3A5F` primary, `#4C6548` secondary) — no gradients, glassmorphism
  or decorative illustration
- **Components:** consistent buttons, cards, tables, badges and form states
  with moderate border radii (7–12px) and subtle shadows only
- **Responsive:** a single fluid layout adapts from mobile through desktop
  via CSS media queries — no separate mobile site

## Future Improvements

- Password reset via email
- Pagination on large admin tables
- Configurable skill-to-category weighting from the Admin Dashboard
- Export of assessment history to PDF
- Multi-language support

---

Built with HTML5, CSS3, Vanilla JavaScript, PHP and MySQL — no frameworks.
